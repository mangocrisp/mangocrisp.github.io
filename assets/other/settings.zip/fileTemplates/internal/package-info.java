/**
 *
 * <pre>
 * ${DESC}
 * </pre>
 *
 * @author XiJieYin
 * @since ${DATE} ${TIME} 
 */
#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end