#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};

/**
 *
 * <pre>
 * ${DESC}
 * </pre>
 *
 * @author XiJieYin
 * @since ${DATE} ${TIME} 
 */
#end
#parse("File Header.java")
public @interface ${NAME} {
}
