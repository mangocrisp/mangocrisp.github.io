/**
 *
 * <pre>
 * ${DESC}
 * </pre>
 *
 * @author XiJieYin
 * @since ${DATE} ${TIME} 
 */
#parse("File Header.java")
module #[[$MODULE_NAME$]]# {
}